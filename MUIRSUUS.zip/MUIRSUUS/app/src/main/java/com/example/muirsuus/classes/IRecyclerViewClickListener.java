package com.example.muirsuus.classes;

import android.view.View;

public interface IRecyclerViewClickListener {
    void onClick(View view, int position);
}
